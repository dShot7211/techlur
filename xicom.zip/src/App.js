import {
  Grid,
  Box,
  FormControl,
  TextField,
  Typography,
  MenuItem,
  Button,
  Checkbox,
} from "@mui/material";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import logo from "./assets/logo.png";
import "./App.css";
import { useState } from "react";
import axios from "axios";
import dayjs from "dayjs";

function App() {
  const [value, setValue] = useState();
  const [typeFile, setTypeFile] = useState("");
  const [imgFile, setImgFile] = useState();
  const [checked, setChecked] = useState(true);
  const d = dayjs("2006-01-01");

  const handleChange = (event) => {
    setChecked(event.target.checked);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData();
    formData.append("fname", form.fname.value);
    formData.append("lname", form.lname.value);
    formData.append("email", form.email.value);
    formData.append("dob", value);
    formData.append(
      "residentialAddress",
      form.rst1.value + " " + form.rst2.value
    );
    // if (checked) {
    formData.append(
      "permanentAddress",
      form.pst1.value + " " + form.pst2.value
    );
    // }

    formData.append("document", imgFile);

    const res = await axios.post(
      "http://localhost:3000/api/v1/users/signup",
      formData
    );

    alert(res?.data.status);
  };
  return (
    <Grid
      container
      className="bg-img center-box"
      sx={{ width: "100vw", height: "100vh" }}
    >
      <Grid item md={7} className="card-css">
        <Box
          component="form"
          id="login_form"
          validate
          autoComplete="off"
          onSubmit={handleSubmit}
          sx={{
            "& .MuiTextField-root": { m: 2 },
            objectFit: "contain",
            overflowY: "scroll",
          }}
        >
          <Grid container sx={{ pt: 1 }}>
            <Grid md={12} sx={{ textAlign: "center" }}>
              <img src={logo} alt="logo" width="40px" />
            </Grid>
            <Grid item md={6} xs={12}>
              <FormControl sx={{ width: "100%" }}>
                <TextField
                  label="First Name"
                  id="fname"
                  size="small"
                  required
                />
              </FormControl>
            </Grid>
            <Grid item md={6} xs={12}>
              <FormControl sx={{ width: "100%" }}>
                <TextField label="Last Name" id="lname" size="small" required />
              </FormControl>
            </Grid>
            <Grid item md={6} xs={12}>
              <FormControl sx={{ width: "100%" }}>
                <TextField label="Email" id="email" size="small" required />
              </FormControl>
            </Grid>

            <Grid item md={6} xs={12}>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DatePicker
                  label="Date of birth"
                  value={value}
                  onChange={(newValue) => setValue(newValue)}
                  sx={{ width: "90%" }}
                  maxDate={d}
                  // disablePast
                />
              </LocalizationProvider>
            </Grid>

            <Grid item md={12} xs={12}>
              <Typography sx={{ ml: 2 }}>Residential Address</Typography>
              <FormControl sx={{ width: "50%" }}>
                <TextField label="Street1" id="rst1" size="small" required />
              </FormControl>
              <FormControl sx={{ width: "50%" }}>
                <TextField label="Street2" id="rst2" size="small" required />
              </FormControl>
            </Grid>
            <Grid item md={12} xs={12}>
              <Typography sx={{ ml: 2 }}>
                {" "}
                <Checkbox
                  checked={checked}
                  onChange={handleChange}
                  inputProps={{ "aria-label": "controlled" }}
                />
                Permanent Address
              </Typography>
              <FormControl sx={{ width: "50%" }}>
                <TextField
                  label="Street1"
                  id="pst1"
                  size="small"
                  required={!checked}
                  disabled={!checked}
                />
              </FormControl>
              <FormControl sx={{ width: "50%" }}>
                <TextField
                  label="Street2"
                  id="pst2"
                  size="small"
                  required={!checked}
                  disabled={!checked}
                />
              </FormControl>
            </Grid>
            <Grid item md={4} xs={12}>
              <FormControl sx={{ width: "100%" }}>
                <TextField label="File Name" id="st1" size="small" required />
              </FormControl>
            </Grid>
            <Grid item md={4} xs={12}>
              <FormControl sx={{ width: "100%" }}>
                <TextField
                  label="Type Of file"
                  id="st1"
                  size="small"
                  required
                  select
                  value={typeFile}
                  onChange={(e) => setTypeFile(e.target.value)}
                >
                  <MenuItem value="jpg">JPG</MenuItem>
                  <MenuItem value="png">PNG</MenuItem>
                  <MenuItem value="jpeg">JPEG</MenuItem>
                </TextField>
              </FormControl>
            </Grid>
            <Grid item md={4} xs={12}>
              <div className="mt-3">
                <input
                  className="form-control"
                  type="file"
                  id="formFile"
                  onChange={(e) => setImgFile(e.target.files[0])}
                />
              </div>
            </Grid>
          </Grid>

          <Box sx={{ textAlign: "center" }}>
            <Button variant="contained" form="login_form" type="submit">
              {" "}
              Submit
            </Button>
          </Box>
        </Box>
      </Grid>
    </Grid>
  );
}

export default App;
